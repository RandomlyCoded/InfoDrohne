Drone prop 65mm with special support ribs by shendriks on Thingiverse: https://www.thingiverse.com/thing:619701

Summary:
Printable drone prop 